﻿namespace Main;

public class SpeedData
{
    public int _value { get; set; }
    public DateTime _dateTime { get; set; }


}
